export class Marks
{
   _id:number;
   Name:string;
   Mark:number;
}