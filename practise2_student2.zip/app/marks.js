"use strict";
var Marks = (function () {
    function Marks() {
    }
    return Marks;
}());
exports.Marks = Marks;
//# sourceMappingURL=marks.js.map