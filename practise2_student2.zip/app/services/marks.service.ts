import {Http,Headers} from '@angular/http';
import {Injectable} from '@angular/core'
import 'rxjs/add/operator/map';

@Injectable()

export class MarksService{
    constructor(private http:Http){
        console.log("MarksService Initialized...")
    }
    
    getMarks(){
        return this.http.get('/api/marks')
            .map(res => res.json());       
    }
    addStudent(newStudent:any){
        var headers = new Headers();
        headers.append('Content-Type','application/json');
        return this.http.post('/api/marks',JSON.stringify(newStudent),{headers:headers})
            .map(res=>res.json());
    }
    dltStudent(_id:any){
        console.log(_id);
        return this.http.delete('/api/marks/'+_id)
             .map(res=>res.json());
    }
}
