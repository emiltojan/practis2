import {Component} from '@angular/core';
import {MarksService} from '../../services/marks.service';
import {Marks} from '../../marks';

@Component({
     moduleId:module.id,
    selector:'add_student',
    templateUrl:'add_student.component.html',
    providers:[MarksService]
})

export class AddStudentComponent{
    
     marks:Marks[]=[];
     _id:number;
     Name:string;
     Mark:number;
     
     constructor(private marksService:MarksService){}
     
  addStudent(event:any){
      event.preventDefault();
    
    var newStudent={
        _id:this._id,
        Name:this.Name,
        Mark:this.Mark
    }
   
    console.log(newStudent);
    this.marksService.addStudent(newStudent).subscribe(
        mark=>{
       
        this.marks.push(mark);
        console.log(mark);
     
        
    });
    
  }
}