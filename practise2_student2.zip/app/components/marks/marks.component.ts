import {Component} from '@angular/core';
import {MarksService} from '../../services/marks.service';
import {Marks} from '../../marks';


@Component({
    moduleId:module.id,
    selector:'marks',
    templateUrl:'marks.component.html',
    providers:[MarksService]
})

export class MarksComponent{
     marks:Marks[];
     
     constructor(private marksService:MarksService){
         this.marksService.getMarks().subscribe(marks=>{
             this.marks = marks;});
     } 
     dltStudent(_id:any)
     {
         var marks = this.marks;
         this.marksService.dltStudent(_id).subscribe(data=>{
             if(data.n==1){
                 for(var i=0;i<marks.length;i++){
                     if(marks[i]._id == _id){
                         marks.splice(i,1);
                     }
                 }
             }
         });
     }
  
    
}