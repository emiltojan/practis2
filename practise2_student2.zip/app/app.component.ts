import {Component} from '@angular/core';
import {MarksComponent} from './components/marks/marks.component'
import {MarksService} from './services/marks.service';

@Component({
    moduleId:module.id,
    selector:'my-app',
    templateUrl:'app.component.html',
    providers:[MarksService]
})

export class AppComponent { }

