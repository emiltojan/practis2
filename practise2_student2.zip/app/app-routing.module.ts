import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AddStudentComponent }  from './components/add_student/add_student.component';
import { MarksComponent }  from './components/marks/marks.component';

const routes: Routes = [
  { path: '', redirectTo: '/marks', pathMatch: 'full' },
  { path: 'marks', component: MarksComponent },
  { path: 'addStudent', component: AddStudentComponent }
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}