var express = require('express');
var Router = express.Router();

const Task = require("./../model/Task");
const TaskController = require("./../controllers/task.controller");

Router.post("/tasks", TaskController.create);
Router.get("/tasks", TaskController.getAll);

Router.get("/tasks/:id", function(req, res){
    let id = req.params.id;
    Task.findOne({_id: id}).exec(function(err, task){
        if(!!err){
            console.error(err);
            res.json({success: false, message: err.message});
        } else {
            res.json({success: true, data: task});
        }
    })
})
Router.put('/tasks/:id', function(req, res){
    let task = req.body;
    let id = req.params.id;

    Task.findByIdAndUpdate(id, {$set: task}, {}, function(err, task){
        if(!!err){
            console.error(err);
            res.json({success: false, message: err.message});
        } else {
            res.json({success: true, data: task});
        }
    })
    
})

Router.delete('/tasks/:id', function(req, res){
    let id = req.params.id;

    Task.remove({_id: id}, function(err){
        if(!!err){
            console.error(err);
            res.json({success: false, message: err.message});
        } else {
            res.json({success: true});
        }
    })
    
})


module.exports = Router;