var express = require('express');
var Router = express.Router();

const tasks = [];
Router.post("/tasks", function(req, res){
    let task = req.body;

    console.log(task);
    tasks.push(task);

    res.json({success: true, data: tasks});
})
Router.get("/tasks", function(req, res){
    res.json({success: true, data: tasks});
})
Router.get("/tasks/:index", function(req, res){
    let index = req.params.index;
    res.json({success: true, data: tasks[index]});
})
Router.put('/tasks/:index', function(req, res){
    let task = req.body;
    tasks[req.params.index] = task;

    res.json({success: true});
})


module.exports = Router;