var express = require('express');
var router = express.Router();
var mongojs = require('mongojs');

var dbName = 'school' 

var db = mongojs('mongodb://127.0.0.1:27017/' + dbName, ['student']);

router.get('/marks', function(req,res,next){
   db.student.find(function(err,marks){
       if(err){
          res.send(err); 
       }
       res.json(marks);
   });
});

//insert a task
router.post('/marks',function(req,res,next){
   var student= req.body;
 
   console.log(student);
   if(!student._id ||!student.Name||!student.Mark){
       res.status(400);
       res.json({'err':'bad data'});
   }
   else{
       db.student.save({_id:student._id,Name:student.Name,Mark:student.Mark},function(err,student){
           if(err){
               res.send(err);
           }
           res.json(student);
       })
   }
    
});

//delete a task
router.delete('/marks/:_id',function(req,res,next){
    db.student.remove({_id:req.params._id},function(err,marks){
       if(err){
           res.send(err);  
       } 
       res.json(marks);
    });
});


module.exports = router;
